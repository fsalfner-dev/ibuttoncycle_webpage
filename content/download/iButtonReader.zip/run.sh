#!/bin/bash
# ------------------------------------------------------------------
# This script runs the iButtonReader script on Linux
#
# The script expects a file called ibuttonreader.properties in the
# current working directory. 
# ------------------------------------------------------------------

# Path to the biolog.properties file
PROPFILE="ibuttonreader.properties"
if [ ! -f "$PROPFILE" ]; then
    echo "Property file $PROPFILE does not exist. Please create file first from the sample file provided."
    exit 1
fi

# Path to libonewireUSB.so and JNI libraries
# the ZIP file contains the library compiled for the amd64 and arm64 platforms. 
ARCHITECTURE=$(uname -m)
if [ "$ARCHITECTURE" == "x86_64" ]; then
    echo "AMD64 architecture detected..."
    ONEWIRELIB="lib/linux/amd64:/usr/local/lib:/usr/lib/jni"
elif [ "$ARCHITECTURE" == "aarch64" ]; then
    echo "ARM64 architecture detected ..."
    ONEWIRELIB="lib/linux/arm64:/usr/local/lib:/usr/lib/jni"
else
    echo "Unsupported architecture: $ARCHITECTURE"
    exit 1
fi

JAVA_LIBS=".:lib/PDKAdapterUSB.jar:lib/OneWireAPI.jar:lib:lib/json-20180813.jar:/usr/share/java/RXTXcomm.jar:lib/IButtonReader.jar"

java -Djava.library.path=$ONEWIRELIB -classpath $JAVA_LIBS -Dproperties.location=$PROPFILE de.salfner.IButtonReader
